"""
Interpreting linear models
==========================

"""

########################################################
# Conditional versus marginal relations
# --------------------------------------------

# The link to univariate feature selection

# The IQ example


########################################################
# The challenge of correlated features
# --------------------------------------------

# Gauging significance of observed associations
# XXX: what to say?


########################################################
# The effect of regularization
# --------------------------------------------


