"""
Cross-validation: some gotchas
===============================

Cross-validation is the ubiquitous test of a machine learning. Yet many
things can go wrong.

"""

###############################################################
# The variance of measured accuracy
# ----------------------------------

###############################################################
# Confounding effects and non independence
# -----------------------------------------

###############################################################
# Permutations to measure chance
# -------------------------------


