"""
Interpreting random forests
============================

Interpreting random forests
"""

#########################################################
# Feature importance
# ----------------------


#########################################################
# Caveats
# -----------------------

# Danger: higher-entropy variables will have large feature importances


