"""
Just a test
===========

This is just a test

"""
print(1)

